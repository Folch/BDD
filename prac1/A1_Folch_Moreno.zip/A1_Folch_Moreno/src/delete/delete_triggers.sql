DROP TRIGGER IF EXISTS update_referee ON partida;
DROP TRIGGER IF EXISTS referee_control ON partida;
DROP TRIGGER IF EXISTS update_ticket ON partida;
