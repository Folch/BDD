/******************************************************************
 *	make.sql de la subcarpeta create                          *
 *		S'encarrega de fer crides als scripts pertinents, *
 *		Per a la creació de taules i tipus de dades.      *
 ******************************************************************/

\i create/create_enums.sql
\i create/create_taules.sql
